﻿using WeatherAPI.Busniess.Interfaces;
using WeatherAPI.Models;
using WeatherAPI.Repository.Interfaces;

namespace WeatherAPI.Busniess.Services
{
    public class WeatherForecastService : IWeatherForecastService
    {
        private readonly IWeatherForecastRepository WeatherForecastRepository;
        public WeatherForecastService(IWeatherForecastRepository weatherForecastRepository)
        {
            WeatherForecastRepository = weatherForecastRepository ?? throw new ArgumentNullException(nameof(weatherForecastRepository));
        }

        public async Task<WeatherForecastModel> GetWeatherForecastAllAsync()
        {
            return await WeatherForecastRepository.GetWeatherForecastAllAsync().ConfigureAwait(false);
        }
    }
}
