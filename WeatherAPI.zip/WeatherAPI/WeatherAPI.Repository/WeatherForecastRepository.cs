﻿using Newtonsoft.Json;
using WeatherAPI.Models;
using WeatherAPI.Repository.Interfaces;

namespace WeatherAPI.Repository
{
    public class WeatherForecastRepository : IWeatherForecastRepository
    {
        public async Task<WeatherForecastModel> GetWeatherForecastAllAsync()
        {
            using (var client = new HttpClient())
            {
                try
                {
                    //string appId = "1910dcfff68e3bb21522383f2bd868da";
                    client.BaseAddress = new Uri("http://api.openweathermap.org");
                    var weatherResponse = await client.GetAsync($"/data/2.5/forecast/daily?lat=44.34&lon=10.99&appid=d0ede38b090df103aa3d9820b956ae6f");
                    //weatherResponse.EnsureSuccessStatusCode();
                    var jsonContent = await weatherResponse.Content.ReadAsStringAsync();
                    var weatherForecast = JsonConvert.DeserializeObject<WeatherForecastModel>(jsonContent);
                    return weatherForecast;
                }
                catch (HttpRequestException httpRequestException)
                {
                    return BadRequest($"Failed to fetch Weather Forecast from OpenWeather: {httpRequestException.Message}");
                }                
            }
        }

        private WeatherForecastModel BadRequest(string v)
        {
            throw new NotImplementedException();
        }
    }
}
