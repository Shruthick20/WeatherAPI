﻿using Microsoft.AspNetCore.Mvc;
using WeatherAPI.Busniess.Interfaces;
using WeatherAPI.Models;

namespace WeatherAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherForecastController : ControllerBase
    {
        private ILogger<WeatherForecastController> Logger;
        private readonly IWeatherForecastService WeatherForecastService;
        public WeatherForecastController(ILogger<WeatherForecastController> logger, IWeatherForecastService weatherForecastService)
        {
            Logger = logger;
            WeatherForecastService = weatherForecastService;
        }

        [HttpGet(Name = "GetWeatherForecast")]
        public async Task<ActionResult<WeatherForecastModel>> GetWeatherForecastAsync()
        {
            var result = await WeatherForecastService.GetWeatherForecastAllAsync().ConfigureAwait(false);
            if (result == null)
                return NoContent();
            return Ok(result);
        }
    }
}
